//
//  RestaurantTableViewCell.swift
//  Resturant
//
//  Created by Gayan Disanayaka on 2/23/21.
//  Copyright © 2021 Gayan Disanayaka. All rights reserved.
//

import UIKit

class RestaurantTableViewCell: UITableViewCell {


    @IBOutlet weak var foodName: UILabel!
    @IBOutlet weak var foodDescription: UILabel!
    @IBOutlet weak var foodPrice: UILabel!
    @IBOutlet weak var foodImage: UIImageView!
    
    
    
    
   
    @IBOutlet weak var homeCartMinusButton: UIButton!
    @IBOutlet weak var homeCartEditCount: UILabel!
    @IBOutlet weak var homeCartPlusButton: UIButton!
    @IBOutlet weak var homeCartMiddleView: UIView!
    @IBOutlet weak var homeCartCornerLabel: UILabel!
    @IBOutlet weak var homeCartName: UILabel!
    
  
    
   
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
