//
//  LocationViewController.swift
//  Café-Nibm
//
//  Created by Gayan Disanayaka on 3/8/21.
//  Copyright © 2021 Gayan Disanayaka. All rights reserved.
//

import UIKit
import CoreLocation

class LocationViewController: UIViewController  {
    
    
    private var locationManager: CLLocationManager?
    
    var latitude = ""
    var longitude = ""
    var cafeDistance = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        

        // Do any additional setup after loading the view.
    }
   
    
    @IBAction func allowLocation(_ sender: Any) {
        
         

           
                locationManager = CLLocationManager()
                locationManager?.requestAlwaysAuthorization()
                locationManager?.startUpdatingLocation()
               
                
                

           
        
        
                
        
              
    }
    
    
    
    @IBAction func cancelLocation(_ sender: Any) {
        
      
        
        let next = self.storyboard?.instantiateViewController(withIdentifier: "HOME_TAB") as! Home_Tab_ViewController
        next.modalPresentationStyle = .fullScreen
        self.present(next, animated: true, completion: nil)
        

    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
          super.viewWillAppear(animated)
          navigationController?.setNavigationBarHidden(true, animated: animated)
          
          
      }

      override func viewWillDisappear(_ animated: Bool) {
          super.viewWillDisappear(animated)
          navigationController?.setNavigationBarHidden(false, animated: animated)
      }

    

  
    
 
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
