//
//  CartTableViewCell.swift
//  Café-Nibm
//
//  Created by Gayan Disanayaka on 3/2/21.
//  Copyright © 2021 Gayan Disanayaka. All rights reserved.
//

import UIKit

class CartTableViewCell: UITableViewCell {

    @IBOutlet weak var amount: UILabel!
    @IBOutlet weak var noItems: UILabel!
    @IBOutlet weak var itemPrice: UILabel!
    @IBOutlet weak var foodName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
