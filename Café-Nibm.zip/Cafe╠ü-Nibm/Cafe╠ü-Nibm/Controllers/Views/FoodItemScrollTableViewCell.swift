//
//  FoodItemScrollTableViewCell.swift
//  Café-Nibm
//
//  Created by Gayan Disanayaka on 2/24/21.
//  Copyright © 2021 Gayan Disanayaka. All rights reserved.
//

import UIKit

class FoodItemScrollTableViewCell: UITableViewCell {

    @IBOutlet weak var bar6: UIButton!
    @IBOutlet weak var bar4: UIButton!
    @IBOutlet weak var bar5: UIButton!
    @IBOutlet weak var bar2: UIButton!
    @IBOutlet weak var bar3: UIButton!
    @IBOutlet weak var bar1: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
