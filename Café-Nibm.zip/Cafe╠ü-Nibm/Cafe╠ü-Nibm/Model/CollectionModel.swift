//
//  CollectionModel.swift
//  Café-Nibm
//
//  Created by Gayan Disanayaka on 3/7/21.
//  Copyright © 2021 Gayan Disanayaka. All rights reserved.
//


import CoreLocation
import  UIKit

class CollectionModel {
    
   
    var imageUrl: String?
    
    init(imageUrl: String?){
        self.imageUrl = imageUrl
        
    }
}
